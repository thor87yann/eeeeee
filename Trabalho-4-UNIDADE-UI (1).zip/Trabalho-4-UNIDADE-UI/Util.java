import java.util.Scanner;

public class Util{

    public static final int ALUNO_LISTA = 0, DOCENTE_LISTA = 1, DISCPLINA_LISTA = 2, TURMA_LISTA = 3;
    
}

